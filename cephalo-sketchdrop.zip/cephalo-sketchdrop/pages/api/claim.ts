import type { NextApiRequest, NextApiResponse } from "next";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "ailin.osteras@gmail.com";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { email, code, password } = req.body || {};
  if (!email || !code || !password) return res.status(400).json({ error: "Missing fields" });

  // Check invite
  const { data: invites, error: invErr } = await supabaseAdmin.from("invites").select("*").eq("email", email).eq("code", code).is("accepted_at", null).limit(1);
  if (invErr) return res.status(500).json({ error: invErr.message });
  if (!invites || invites.length === 0) return res.status(400).json({ error: "Invalid code or already used" });

  // Create user
  const isAdmin = String(email).toLowerCase() === String(ADMIN_EMAIL).toLowerCase();
  const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { is_admin: isAdmin }
  });
  if (createErr) return res.status(400).json({ error: createErr.message });

  // Mark invite used
  const { error: updErr } = await supabaseAdmin.from("invites").update({ accepted_at: new Date().toISOString() }).eq("email", email);
  if (updErr) console.error("Failed to mark invite used:", updErr.message);

  return res.status(200).json({ ok: true, user_id: created.user?.id });
}
