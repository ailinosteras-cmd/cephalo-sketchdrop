import type { NextApiRequest, NextApiResponse } from "next";
import { supabase } from "@/lib/supabase";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

async function getUserFromAuthHeader(req: NextApiRequest) {
  const auth = req.headers.authorization;
  if (!auth) return null;
  const token = auth.replace("Bearer ", "");
  const client = supabase as any;
  const u = await client.auth.getUser(token);
  return u.data.user ?? null;
}

function generateCode() {
  return Math.random().toString(36).slice(2,8).toUpperCase();
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const user = await getUserFromAuthHeader(req);
  if (!user || !user.user_metadata?.is_admin) return res.status(403).json({ error: "Admin only" });

  const { email } = req.body || {};
  if (!email || typeof email !== "string") return res.status(400).json({ error: "Email required" });

  const code = generateCode();
  // Upsert invite
  const { error: upErr } = await supabaseAdmin.from("invites").upsert({ email, code }, { onConflict: "email" });
  if (upErr) return res.status(500).json({ error: upErr.message });

  // Send email via Resend if configured
  try {
    const apiKey = process.env.RESEND_API_KEY;
    const origin = req.headers["x-forwarded-proto"] && req.headers["x-forwarded-host"]
      ? `${req.headers["x-forwarded-proto"]}://${req.headers["x-forwarded-host"]}`
      : (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000");
    const claimUrl = `${origin}/claim?email=${encodeURIComponent(email)}&code=${encodeURIComponent(code)}`;
    if (apiKey) {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: "Cephalo SketchDrop <noreply@sketchdrop.cephalo>",
          to: [email],
          subject: "Your SketchDrop access code",
          text: `Your access code is ${code}.\nClaim it here: ${claimUrl}`
        })
      });
      if (!r.ok) {
        const t = await r.text();
        console.error("Resend error:", t);
      }
    } else {
      console.log(`[DEV] Invite for ${email}: ${code} | ${claimUrl}`);
    }
  } catch (e) {
    console.error("Email send error:", e);
  }

  return res.status(200).json({ ok: true, code });
}
