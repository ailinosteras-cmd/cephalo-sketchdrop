import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import Layout from "@/components/Layout";
import LoginForm from "@/components/LoginForm";
import AssetCard, { type Asset } from "@/components/AssetCard";

export default function AdminPage() {
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [assets, setAssets] = useState<Asset[]>([]);
  const [lastInvite, setLastInvite] = useState<{ email: string; code: string } | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  const isAdmin = !!user?.user_metadata?.is_admin;

  useEffect(() => {
    if (!isAdmin) return;
    supabase.from("assets").select("*").order("created_at", { ascending: false }).then(({ data }) => setAssets((data as Asset[])||[]));
  }, [isAdmin]);

  const invite = async () => {
    if (!email) return;
    const token = (await supabase.auth.getSession()).data.session?.access_token;
    const res = await fetch("/api/invite", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ email })
    });
    const data = await res.json();
    if (!res.ok) { alert(data.error||"Failed"); return; }
    setLastInvite({ email, code: data.code });
    setEmail("");
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this asset?")) return;
    await supabase.from("assets").delete().eq("id", id);
    setAssets(prev => prev.filter(a=>a.id!==id));
  };

  if (!user) return <Layout><LoginForm /></Layout>;
  if (!isAdmin) return <Layout><div className="card">Admins only.</div></Layout>;

  return (
    <Layout>
      <div className="card space-y-3">
        <h3 className="font-semibold">Admin controls</h3>
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-2">
          <input className="input" placeholder="Invite user by email" value={email} onChange={e=>setEmail(e.target.value)} />
          <button className="btn btn-primary" onClick={invite}>Add & send code</button>
        </div>
        {lastInvite && <div className="text-sm bg-slate-50 border border-slate-200 rounded-xl p-3">
          Sent access code <span className="font-mono">{lastInvite.code}</span> to <span className="underline">{lastInvite.email}</span>.
        </div>}
        <p className="text-xs text-slate-500">Codes are emailed via Resend if configured, otherwise logged by the API.</p>
      </div>

      <div className="card mt-6">
        <h3 className="font-semibold mb-3">All uploads ({assets.length})</h3>
        {assets.length===0 ? <p className="text-slate-600">No assets uploaded yet.</p> : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {assets.map(a=> <AssetCard key={a.id} asset={a} canDelete onDelete={()=>remove(a.id)} />)}
          </div>
        )}
      </div>
    </Layout>
  );
}
