import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import Layout from "@/components/Layout";

export default function ClaimPage() {
  const router = useRouter();
  const [email, setEmail] = useState<string>("");
  const [code, setCode] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [msg, setMsg] = useState<string>("");

  useEffect(() => {
    if (typeof router.query.email === "string") setEmail(router.query.email);
    if (typeof router.query.code === "string") setCode(router.query.code);
  }, [router.query]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg("");
    const res = await fetch("/api/claim", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, code, password }) });
    const data = await res.json();
    if (!res.ok) { setMsg(data.error || "Failed to claim invite."); return; }
    setMsg("Account created! You can now sign in on the homepage.");
  };

  return (
    <Layout>
      <div className="max-w-md mx-auto card space-y-4">
        <h2 className="text-lg font-semibold">Claim Access</h2>
        <form onSubmit={submit} className="space-y-3">
          <input className="input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required />
          <input className="input" placeholder="Access code" value={code} onChange={e=>setCode(e.target.value)} required />
          <input className="input" type="password" placeholder="Create a password" value={password} onChange={e=>setPassword(e.target.value)} required />
          <button className="btn btn-primary w-full" type="submit">Claim Access</button>
        </form>
        {msg && <p className="text-sm">{msg}</p>}
      </div>
    </Layout>
  );
}
