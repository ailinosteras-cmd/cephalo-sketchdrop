import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";
import Layout from "@/components/Layout";
import AssetCard, { type Asset } from "@/components/AssetCard";
import LoginForm from "@/components/LoginForm";
import { Search } from "lucide-react";

export default function Home() {
  const [sessionUser, setSessionUser] = useState<any>(null);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSessionUser(data.session?.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSessionUser(s?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!sessionUser) return;
    supabase.from("assets").select("*").order("created_at", { ascending: false }).then(({ data })=> setAssets((data as Asset[])||[]));
  }, [sessionUser]);

  const isAdmin = !!sessionUser?.user_metadata?.is_admin;

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return assets;
    return assets.filter(a => 
      a.name.toLowerCase().includes(term) ||
      (a.tags||[]).some(t => t.toLowerCase().includes(term))
    );
  }, [q, assets]);

  const remove = async (id: string) => {
    if (!confirm("Delete this asset?")) return;
    await supabase.from("assets").delete().eq("id", id);
    setAssets(prev => prev.filter(a=>a.id!==id));
    // TODO: also delete storage object (optional - admin page handles bulk clean-up)
  };

  if (!sessionUser) {
    return (
      <Layout>
        <header className="text-center space-y-2 mb-6">
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">Welcome to <span className="text-indigo-600">Cephalo</span> // SketchDrop</h1>
          <p className="text-slate-600">Discover, share, and download illustrations and photos.</p>
        </header>
        <LoginForm />
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex items-center gap-3 mb-4">
        <input className="input" placeholder="Search by keyword or tag..." value={q} onChange={e=>setQ(e.target.value)} />
        <div className="hidden sm:block text-slate-500"><Search className="w-4 h-4 inline mr-1"/>Search</div>
      </div>
      {filtered.length===0 ? <div className="card text-center text-slate-600">No assets found. Try different tags or upload something!</div> : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filtered.map(asset => (
            <AssetCard key={asset.id} asset={asset} canDelete={isAdmin || asset.user_id===sessionUser.id} onDelete={()=>remove(asset.id)} />
          ))}
        </div>
      )}
    </Layout>
  );
}
