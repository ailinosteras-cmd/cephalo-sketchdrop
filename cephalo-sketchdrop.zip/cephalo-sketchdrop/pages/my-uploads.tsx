import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import Layout from "@/components/Layout";
import LoginForm from "@/components/LoginForm";
import AssetCard, { type Asset } from "@/components/AssetCard";

export default function MyUploads() {
  const [user, setUser] = useState<any>(null);
  const [assets, setAssets] = useState<Asset[]>([]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;
    supabase.from("assets").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).then(({ data }) => setAssets((data as Asset[])||[]));
  }, [user]);

  const remove = async (id: string) => {
    if (!confirm("Delete this asset?")) return;
    await supabase.from("assets").delete().eq("id", id);
    setAssets(prev => prev.filter(a=>a.id!==id));
  };

  if (!user) return <Layout><LoginForm /></Layout>;
  return (
    <Layout>
      {assets.length===0 ? <div className="card">You haven't uploaded anything yet.</div> : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {assets.map(a=> <AssetCard key={a.id} asset={a} canDelete onDelete={()=>remove(a.id)} />)}
        </div>
      )}
    </Layout>
  );
}
