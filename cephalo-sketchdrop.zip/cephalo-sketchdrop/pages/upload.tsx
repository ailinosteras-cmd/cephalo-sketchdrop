import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import Layout from "@/components/Layout";
import LoginForm from "@/components/LoginForm";
import UploadForm from "@/components/UploadForm";

export default function UploadPage() {
  const [user, setUser] = useState<any>(null);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!user) return <Layout><LoginForm /></Layout>;
  return <Layout><UploadForm user={user} /></Layout>;
}
