import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { useEffect } from "react";
import { supabase } from "@/lib/supabase";

export default function App({ Component, pageProps }: AppProps) {
  // Hydrate session to avoid FOUC
  useEffect(() => { supabase.auth.getSession(); }, []);
  return <Component {...pageProps} />;
}
