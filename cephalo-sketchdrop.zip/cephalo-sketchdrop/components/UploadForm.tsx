import { useState } from "react";
import { supabase } from "@/lib/supabase";

export default function UploadForm({ user }: { user: any }) {
  const [file, setFile] = useState<File | null>(null);
  const [tags, setTags] = useState("");
  const [name, setName] = useState("");
  const [consent, setConsent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !user) return;
    setLoading(true);

    const fileExt = file.name.split(".").pop();
    const filePath = `${user.id}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("assets")
      .upload(filePath, file);

    if (uploadError) {
      alert(uploadError.message);
      setLoading(false);
      return;
    }

    const { data } = supabase.storage.from("assets").getPublicUrl(filePath);

    const { error: dbError } = await supabase.from("assets").insert({
      user_id: user.id,
      name: name || file.name,
      tags: tags ? tags.split(/[,#\s]+/).filter(Boolean) : [],
      url: data.publicUrl,
      consent,
    });

    if (dbError) alert(dbError.message);
    else {
      setFile(null); setName(""); setTags(""); setConsent(false);
      alert("Uploaded successfully!");
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleUpload} className="space-y-4 card">
      <input type="file" onChange={e => setFile(e.target.files?.[0] ?? null)} />
      <div className="grid sm:grid-cols-2 gap-3">
        <input className="input" value={name} onChange={e=>setName(e.target.value)} placeholder="Name" />
        <input className="input" value={tags} onChange={e=>setTags(e.target.value)} placeholder="Tags (comma or space separated)" />
      </div>
      <label className="flex items-start gap-2 text-sm">
        <input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)} className="mt-1"/>
        <span>This is a photo/illustration created by me using AI. I take full responsibility and allow others to use it freely.</span>
      </label>
      <button className="btn btn-primary" disabled={loading}>{loading ? "Uploading..." : "Upload"}</button>
    </form>
  );
}
