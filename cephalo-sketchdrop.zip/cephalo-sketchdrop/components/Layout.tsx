import Link from "next/link";
import { LogOut } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useEffect, useState } from "react";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [email, setEmail] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      const u = data.session?.user;
      setEmail(u?.email ?? null);
      setIsAdmin(!!u?.user_metadata?.is_admin);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      const u = s?.user;
      setEmail(u?.email ?? null);
      setIsAdmin(!!u?.user_metadata?.is_admin);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white/80 backdrop-blur border-b border-slate-200">
        <div className="container py-3 flex items-center gap-3">
          <div className="flex items-center gap-2 font-semibold">
            <div className="w-8 h-8 rounded-xl bg-indigo-600" />
            <span>Cephalo // SketchDrop</span>
          </div>
          <nav className="ml-6 flex items-center gap-2 text-sm">
            <Link className="px-3 py-1.5 rounded-lg hover:bg-slate-100" href="/">Library</Link>
            <Link className="px-3 py-1.5 rounded-lg hover:bg-slate-100" href="/upload">Upload</Link>
            <Link className="px-3 py-1.5 rounded-lg hover:bg-slate-100" href="/my-uploads">My uploads</Link>
            {isAdmin && <Link className="px-3 py-1.5 rounded-lg hover:bg-slate-100" href="/admin">Admin</Link>}
          </nav>
          <div className="ml-auto flex items-center gap-4 text-sm">
            {email && <span className="hidden sm:block text-slate-600">Signed in as <span className="font-medium">{email}</span>{isAdmin && <span className="ml-1 text-amber-700">(admin)</span>}</span>}
            {email && <button className="btn btn-ghost" onClick={() => supabase.auth.signOut()}><LogOut className="w-4 h-4"/> Sign out</button>}
          </div>
        </div>
      </header>
      <main className="container py-6 flex-1">{children}</main>
      <footer className="container py-8 text-xs text-slate-500">© Cephalo // SketchDrop</footer>
    </div>
  );
}
