import { Download, Trash2, Image as ImageIcon } from "lucide-react";

export type Asset = {
  id: string;
  user_id: string | null;
  name: string;
  tags: string[];
  url: string;
  consent: boolean;
  created_at: string;
};

export default function AssetCard({
  asset,
  canDelete,
  onDelete
}: {
  asset: Asset;
  canDelete?: boolean;
  onDelete?: () => void;
}) {
  const canPreviewImage = asset.url.match(/\.(png|jpe?g|gif|webp|svg|heic|heif)$/i);
  return (
    <div className="group relative rounded-2xl overflow-hidden ring-1 ring-slate-200 bg-white">
      <div className="aspect-[4/3] bg-slate-50 flex items-center justify-center overflow-hidden">
        {canPreviewImage ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={asset.url} alt={asset.name} className="w-full h-full object-cover" />
        ) : (
          <div className="flex flex-col items-center gap-2 text-slate-500">
            <ImageIcon className="w-8 h-8" />
            <span className="text-xs">FILE</span>
          </div>
        )}
      </div>
      <div className="p-3">
        <div className="text-sm font-medium line-clamp-1" title={asset.name}>{asset.name}</div>
        <div className="mt-1 flex items-center gap-1 flex-wrap">
          {asset.tags?.slice(0,3).map((t,i)=>(<span key={i} className="pill">#{t}</span>))}
          {asset.tags && asset.tags.length>3 && <span className="pill">+{asset.tags.length-3}</span>}
        </div>
        <div className="mt-2 flex items-center justify-between">
          <a href={asset.url} download className="inline-flex items-center gap-1 text-sm"><Download className="w-4 h-4"/>Download</a>
          {canDelete && <button className="text-rose-600 hover:text-rose-700" onClick={onDelete} title="Delete"><Trash2 className="w-4 h-4" /></button>}
        </div>
      </div>
    </div>
  );
}
