import { useState } from "react";
import { supabase } from "@/lib/supabase";
import Link from "next/link";

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setErr(error.message);
  };

  return (
    <div className="max-w-md mx-auto card space-y-4">
      <h2 className="text-lg font-semibold">Sign in</h2>
      <form onSubmit={onSubmit} className="space-y-3">
        <input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" required />
        <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" required />
        {err && <p className="text-rose-600 text-sm">{err}</p>}
        <button className="btn btn-primary w-full" type="submit">Sign in</button>
      </form>
      <p className="text-sm">Invited? <Link href="/claim" className="underline">Claim access with your code</Link>.</p>
    </div>
  );
}
