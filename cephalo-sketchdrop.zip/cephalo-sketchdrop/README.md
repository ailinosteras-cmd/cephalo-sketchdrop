# Cephalo // SketchDrop (Next.js + Supabase)

## Quick start
1. Copy `.env.local.example` to `.env.local` and fill Supabase keys.
2. Create a Supabase project, storage bucket `assets`, and run `supabase/schema.sql` in SQL Editor.
3. (Optional) Set `RESEND_API_KEY` for invite emails, otherwise codes will be logged by the API.
4. `npm install` then `npm run dev`.

## Admin
The email in `ADMIN_EMAIL` (defaults to `ailin.osteras@gmail.com`) is flagged admin when claiming their invite.
Use `/admin` to invite users and manage uploads.
