-- Enable pgcrypto/uuid if needed
create extension if not exists pgcrypto;
create extension if not exists "uuid-ossp";

-- Invites
create table if not exists public.invites (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  code text not null,
  created_at timestamptz default now(),
  accepted_at timestamptz
);
alter table public.invites enable row level security;
-- Only admins can read invites (clients seldom need to)
drop policy if exists "read invites admin" on public.invites;
create policy "read invites admin" on public.invites for select
  to authenticated using (coalesce((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean, false));
-- Inserts/updates handled by service role in API -> no public policy for insert/update/delete

-- Assets
create table if not exists public.assets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  name text not null,
  tags text[],
  url text not null,
  consent boolean default false,
  created_at timestamptz default now()
);
alter table public.assets enable row level security;

-- Read: any authenticated user
drop policy if exists "read assets" on public.assets;
create policy "read assets" on public.assets for select to authenticated using (true);

-- Insert: only owner
drop policy if exists "insert assets" on public.assets;
create policy "insert assets" on public.assets for insert to authenticated with check (user_id = auth.uid());

-- Delete: owner or admin
drop policy if exists "delete assets" on public.assets;
create policy "delete assets" on public.assets for delete to authenticated using (
  user_id = auth.uid() or coalesce((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean, false)
);

-- Storage bucket policies (create a bucket named 'assets' in the dashboard)
-- Example RLS on storage.objects:
-- Note: adjust if your schema has a different table for objects
--
-- create policy "public read assets" on storage.objects for select to public
--   using (bucket_id = 'assets');
-- create policy "upload own assets" on storage.objects for insert to authenticated
--   with check (bucket_id = 'assets' and auth.uid()::text = split_part(name, '/', 1));
-- create policy "delete own or admin assets" on storage.objects for delete to authenticated
--   using (bucket_id = 'assets' and (auth.uid()::text = split_part(name, '/', 1)
--     or coalesce((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean, false)));
