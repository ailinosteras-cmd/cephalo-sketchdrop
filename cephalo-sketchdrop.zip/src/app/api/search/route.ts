
export { GET as default } from '@/src/app/api/uploads/list/route'
